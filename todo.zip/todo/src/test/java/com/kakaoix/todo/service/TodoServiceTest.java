package com.kakaoix.todo.service;

import com.kakaoix.todo.domain.TodoDetail;
import com.kakaoix.todo.domain.TodoMaster;
import com.kakaoix.todo.domain.mixedId.TodoDetailId;
import com.kakaoix.todo.fixture.TodoDataFixture;
import com.kakaoix.todo.request.SearchRequest;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import javax.annotation.Resource;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@SpringBootTest
@Transactional
public class TodoServiceTest {

    @Resource
    TodoService todoService;

    @Test
    public void initialize(){ assertNotNull(todoService); }

    @Test
    public void test() throws NoSuchFieldException {
        SearchRequest req = new SearchRequest();
        req.setPageNumber(0);
        req.setPageSize(1);
        Page<TodoMaster> page = todoService.getPage(req);
        TodoMaster todoMaster = page.getContent().get(0);
        Class clazz = todoMaster.getClass();
        Field[] dField = clazz.getDeclaredFields();
        List<String> fieldNames = new ArrayList<>();
        for (Field field : dField){
            if( "todoDetails".equals(field.getName()) ){
                fieldNames.add(field.getName());
            }
        }

    }

    @Test
    public void list(){
        SearchRequest req = new SearchRequest();
        req.setPageNumber(0);
        req.setPageSize(1);
        Page<TodoMaster> page = todoService.getPage(req);
        assertNotNull(page);
        assertFalse(page.isEmpty());
    }

    @Test
    public void findAllById(){
        List<Long> ids = new ArrayList<>(Arrays.asList(25L,26L,27L));
        List<TodoMaster> masters = todoService.findAllById(ids);
        assertNotNull(masters);
        assertEquals(masters.size(), 3);
    }

    @Test
    public void detail(){
        long todoId = 14;
        TodoMaster master = todoService.findById(todoId);
        assertNotNull(master);
        assertEquals(master.getTodoDetails().size(), 3);
    }

    @Test
    public void save(){
        TodoMaster todoMaster = TodoDataFixture.param(TodoMaster.class);
        todoMaster.setName("Test gogo4");
        todoMaster.setStatus(true);
        TodoMaster master = todoService.save(todoMaster);
        assertNotNull(master);
    }

    @Test
    public void modify(){
        TodoMaster masterData = TodoDataFixture.param(TodoMaster.class);
        masterData.setTodoId(17);
        masterData.setName("Test gogo1234");
        masterData.setStatus(false);
        masterData.setTodoDetails(null);
        TodoMaster master = todoService.modify(masterData);
        assertNotNull(master);
    }

    @Test
    public void delete(){
        todoService.delete(32);
    }

}
