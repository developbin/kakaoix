package com.kakaoix.todo.mock;

import com.kakaoix.todo.domain.TodoDetail;
import com.kakaoix.todo.domain.TodoMaster;
import com.kakaoix.todo.domain.mixedId.TodoDetailId;
import com.kakaoix.todo.fixture.TodoDataFixture;
import jdk.internal.jline.internal.Log;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import javax.annotation.Resource;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;

@SpringBootTest
@AutoConfigureMockMvc
public class TodoMockTest {

    @Resource
    private MockMvc mockMvc;

    @Test
    public void initialize() {
        assertNotNull(mockMvc);
    }

    @Test
    public void list() throws Exception {
        mockMvc.perform(get("/todo/list?name=Test&pageNumber=1&pageSize=3"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.empty").value(false))
                .andDo(print());
    }

    @Test
    public void listIds() throws Exception {
        mockMvc.perform(get("/todo/list/ids").param("ids","25").param("ids","26").param("ids","27"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$[0].todoId").value("25"))
                .andExpect(jsonPath("$[1].todoId").value("26"))
                .andExpect(jsonPath("$[2].todoId").value("27"))
                .andDo(print());
    }

    @Test
    public void detail() throws Exception {
        long todoId = 18;
        mockMvc.perform(get("/todo/detail/"+todoId))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.todoId").value(18))
                .andDo(print());
    }

    @Test
    public void save() throws Exception {
        TodoMaster todoMaster = TodoDataFixture.param(TodoMaster.class);
        todoMaster.setName("Test 고고고1?");
        todoMaster.setStatus(false);
        todoMaster.setTodoDetails(null);
        todoMaster.setAddDt(null);

        String bodyJson = TodoDataFixture.gson.toJson(todoMaster);

        mockMvc.perform(post("/todo/save").content(bodyJson).contentType(MediaType.APPLICATION_JSON).characterEncoding("UTF-8"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.todoId").value(31))
                .andDo(print());
    }

    @Test
    public void modify() throws Exception {
        TodoMaster todoMaster = new TodoMaster();
        todoMaster.setTodoId(31);
        todoMaster.setName("Test 34");
        todoMaster.setStatus(true);
        todoMaster.setAddDt(null);

        String bodyJson = TodoDataFixture.gson.toJson(todoMaster);

        mockMvc.perform(put("/todo/modify").content(bodyJson).contentType(MediaType.APPLICATION_JSON).characterEncoding("UTF-8"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.todoId").value(31))
                .andDo(print());
    }

    @Test
    public void del() throws Exception {
        String _todoId = "34";
        mockMvc.perform(delete("/todo/delete/"+_todoId))
                .andExpect(status().isOk())
                .andDo(print());
    }

}