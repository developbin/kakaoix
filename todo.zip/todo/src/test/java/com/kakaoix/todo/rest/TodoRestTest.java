package com.kakaoix.todo.rest;

import com.kakaoix.todo.domain.TodoMaster;
import com.kakaoix.todo.fixture.TodoDataFixture;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.Nullable;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class TodoRestTest {

    @LocalServerPort
    int randomServerPort;

    RestTemplate rest = new RestTemplate();

    @Test
    public void list(){
        String result = rest.getForObject(url("/todo/list?name=Test&pageNumber=1&pageSize=3"), String.class);
        assertNotNull(result);
    }

    @Test
    public void listIds(){
        String result = rest.getForObject(url("/todo/list/ids?ids=25&ids=26&ids27"), String.class);
        assertNotNull(result);
    }

    @Test
    public void detail(){
        long todoId = 22;
        ResponseEntity<TodoMaster> result = rest.getForEntity(url("/todo/detail/"+todoId), TodoMaster.class);
        assertNotNull(result.getBody());
        assertEquals(result.getStatusCodeValue(), 200);
        assertEquals(result.getBody().getTodoId(), 22);
    }

    @Test
    public void save(){
        String name = "Test gogo5";
        TodoMaster todoMaster = TodoDataFixture.param(TodoMaster.class);
        todoMaster.setName(name);
        todoMaster.setStatus(false);
        TodoMaster result = rest.postForObject(url("/todo/save"), todoMaster, TodoMaster.class);
        assertNotNull(result);
        assertEquals(result.getName(), name);
        assertFalse(result.isStatus());
    }

    @Test
    public void modify(){
        long todoId = 33;
        String name = "Test 333";

        TodoMaster todoMaster = new TodoMaster();
        todoMaster.setTodoId(todoId);
        todoMaster.setName(name);
        todoMaster.setStatus(true);

        rest.put(url("/todo/modify"), todoMaster);
    }

    @Test
    public void delete(){
        long todoId = 35;
        rest.delete(url("/todo/delete/"+todoId));
    }

    private String url(String url){
        return "http://localhost:"+randomServerPort+"/api"+url;
    }

}
