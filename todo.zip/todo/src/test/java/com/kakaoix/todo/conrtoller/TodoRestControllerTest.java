package com.kakaoix.todo.conrtoller;

import com.kakaoix.todo.controller.TodoRestController;
import com.kakaoix.todo.domain.TodoMaster;
import com.kakaoix.todo.domain.mixedId.TodoDetailId;
import com.kakaoix.todo.fixture.TodoDataFixture;
import com.kakaoix.todo.request.SearchRequest;
import com.kakaoix.todo.service.TodoService;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@Transactional
public class TodoRestControllerTest {

    @Resource
    private TodoRestController todoRestController;

    @Test
    public void initialize() {
        assertNotNull(todoRestController);
    }

    @Test
    public void list(){
        SearchRequest req = new SearchRequest();
        req.setPageNumber(0);
        req.setPageSize(1);
        req.setName("1234");
        ResponseEntity<Page<TodoMaster>> responseEntity = todoRestController.list(req);
        Page<TodoMaster> body = responseEntity.getBody();
        assertNotNull(body);
        assertNotNull(body.getContent());
        assertFalse(body.isEmpty());
        assertEquals(body.getTotalElements(), 1);
        assertEquals(responseEntity.getStatusCodeValue(), 200);
    }

    @Test
    public void listIds(){
        List<Long> ids = new ArrayList<>(Arrays.asList(25L,26L,27L));
        ResponseEntity<List<TodoMaster>> responseEntity = todoRestController.listIds(ids);
        assertNotNull(responseEntity.getBody());
        assertEquals(responseEntity.getStatusCodeValue(), 200);
        assertEquals(responseEntity.getBody().size(), 3);
    }

    @Test
    public void detail(){
        long todoId = 17;
        ResponseEntity<TodoMaster> responseEntity = todoRestController.detail(todoId);
        assertNotNull(responseEntity.getBody());
        assertEquals(responseEntity.getStatusCodeValue(), 200);
        assertEquals(responseEntity.getBody().getTodoId(), 17);
    }

    @Test
    public void save(){
        TodoMaster todoMaster = TodoDataFixture.param(TodoMaster.class);
        todoMaster.setName("Test go");
        todoMaster.setStatus(false);
        ResponseEntity<TodoMaster> responseEntity = todoRestController.save(todoMaster);
        assertNotNull(responseEntity.getBody());
        assertEquals(responseEntity.getStatusCodeValue(), 200);
        assertEquals(responseEntity.getBody().getTodoId(), 23);
    }

    @Test
    public void modify(){
        TodoMaster todoMaster = new TodoMaster();
        todoMaster.setTodoId(23);
        todoMaster.setName("Test 23");
        todoMaster.setStatus(true);
        ResponseEntity<TodoMaster> responseEntity = todoRestController.modify(todoMaster);
        assertNotNull(responseEntity.getBody());
        assertEquals(responseEntity.getStatusCodeValue(), 200);
        assertEquals(responseEntity.getBody().getTodoId(), 23);
        assertEquals(responseEntity.getBody().getName(),"Test 23");
        assertTrue(responseEntity.getBody().isStatus());
    }

    @Test
    public void delete(){
        long todoId = 34;
        ResponseEntity<?> responseEntity = todoRestController.delete(todoId);
        assertEquals(responseEntity.getStatusCodeValue(), 200);
    }

}
