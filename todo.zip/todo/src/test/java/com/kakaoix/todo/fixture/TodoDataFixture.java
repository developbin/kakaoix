package com.kakaoix.todo.fixture;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.HashMap;
import java.util.Map;

public class TodoDataFixture {
    public static Gson gson = new GsonBuilder().create();
    public static Map<String, String> data;
    static {
        data = new HashMap<>();
        data.put("TodoMaster",""
        + "{\r\n" +
            " \"todoDetails\" : \r\n" +
            " [\r\n"+
                "{\r\n"+
                    " \"todoDetailId\" : " +
                    " {\r\n" +
                        " \"referTodoId\" : \"3\"\r\n" +
                    " }\r\n"+
                "},\r\n"+
                "{\r\n"+
                    " \"todoDetailId\" : " +
                    " {\r\n" +
                        " \"referTodoId\" : \"1\"\r\n" +
                    " }\r\n"+
                "},\r\n"+
                "{\r\n"+
                    " \"todoDetailId\" : " +
                    " {\r\n" +
                        " \"referTodoId\" : \"2\"\r\n" +
                    " }\r\n"+
                "}\r\n"+
            " ]\r\n"+
          "}"
        );
    }

    public static <T> T param(Class<T> clazz){
        return gson.fromJson(data.get(clazz.getSimpleName()), clazz);
    }

}
