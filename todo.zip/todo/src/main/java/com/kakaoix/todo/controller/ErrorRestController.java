package com.kakaoix.todo.controller;

import com.kakaoix.todo.error.TodoException;
import com.kakaoix.todo.response.ErrorResponse;
import javassist.NotFoundException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.http.HttpStatus;

@RestControllerAdvice
public class ErrorRestController {
    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    protected ErrorResponse defaultException(Exception e){
        return new ErrorResponse("Exception",999,e.getMessage());
    }

    @ExceptionHandler(TodoException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    protected ErrorResponse TodoException(TodoException e){
        return new ErrorResponse("TodoException",100,e.getMessage());
    }
}
