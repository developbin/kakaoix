package com.kakaoix.todo.service;

import com.kakaoix.todo.domain.TodoMaster;
import com.kakaoix.todo.domain.mixedId.TodoDetailId;
import com.kakaoix.todo.error.TodoException;
import com.kakaoix.todo.repository.TodoDetailRepository;
import com.kakaoix.todo.repository.TodoMasterRepository;
import com.kakaoix.todo.repository.specs.SearchOperation;
import com.kakaoix.todo.request.SearchRequest;
import com.kakaoix.todo.resolver.FileArgumentResolver;
import com.kakaoix.todo.repository.specs.SearchCriteria;
import com.kakaoix.todo.repository.specs.TodoMasterSpecification;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.Hibernate;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Slf4j
@Service
@Transactional
@AllArgsConstructor
public class TodoService {
    private TodoMasterRepository masterRepository;
    private TodoDetailRepository detailRepository;
    private FileArgumentResolver fileArgResolver;

    public ByteArrayInputStream download(SearchRequest searchRequest) {
        Page<TodoMaster> pageTodoMaster = searchPage(searchRequest);
        List<TodoMaster> masters = pageTodoMaster.getContent();

        if( masters.size() == 0 ) throw new TodoException("검색된 데이터가 존재하지 않습니다.");

        return fileArgResolver.excelDownload(masters);
    }

    public List<String> upload(List<MultipartFile> files){
        return fileArgResolver.upload(files);
    }

    @Transactional(readOnly = true)
    public Page<TodoMaster> getPage(SearchRequest searchRequest){
        return searchPage(searchRequest);
    }

    @Transactional(readOnly = true)
    public List<TodoMaster> findAllById(List<Long> longs){
        List<TodoMaster> todoMasters = masterRepository.findAllById(longs);
        todoMasters.forEach(this::hibernateInit);
        return masterRepository.findAllById(longs);
    }

    @Transactional(readOnly = true)
    public TodoMaster findById(long id){
        TodoMaster todoMaster = getTodoMaster(id);
        hibernateInit(todoMaster);
        return todoMaster;
    }

    public TodoMaster save(TodoMaster master){
        master.setAddDt(LocalDateTime.now());
        TodoMaster todoMaster = masterRepository.save(master);
        if( !CollectionUtils.isEmpty(master.getTodoDetails()) ){
            master.getTodoDetails().forEach(item->{
                TodoDetailId todoDetailId = item.getTodoDetailId();
                todoDetailId.setTodoId(todoMaster.getTodoId());
                todoDetailId.setReferTodoId(todoDetailId.getReferTodoId());
                item.setTodoDetailId(todoDetailId);
                detailRepository.save(item);
            });
        }
        return masterRepository.save(master);
    }

    public TodoMaster modify(TodoMaster master){
        TodoMaster todoMaster = getTodoMaster(master.getTodoId());
        todoMaster.setName(master.getName());
        todoMaster.setStatus(master.isStatus());
        todoMaster.setModifyDt(LocalDateTime.now());
        hibernateInit(todoMaster);
        return todoMaster;
    }

    public void delete(long id){
        TodoMaster master = new TodoMaster();
        master.setTodoId(id);
        TodoMaster todoMaster = getTodoMaster(master.getTodoId());
        masterRepository.delete(todoMaster);
    }

    private void hibernateInit(TodoMaster todoMaster){
        Hibernate.initialize(todoMaster.getTodoDetails());
    }

    private TodoMaster getTodoMaster(long todoId){
        return masterRepository.findById(todoId).orElseThrow(()->new TodoException("todoId is not found"));
    }

    private void whereGeneration(SearchRequest searchRequest, TodoMasterSpecification specification){
        if( null == specification) return;
        if( StringUtils.hasText(searchRequest.getName()) ){
            specification.add(new SearchCriteria("name",searchRequest.getName(), SearchOperation.MATCH));
        }
        if( null != searchRequest.getStat() ){
            specification.add(new SearchCriteria("status",searchRequest.getStat(), SearchOperation.EQUAL));
        }
        if( null != searchRequest.getStartDt() && null != searchRequest.getEndDt() ){
            specification.add(new SearchCriteria("addDt",searchRequest.getStartDt(), searchRequest.getEndDt(), SearchOperation.BETWEEN));
        }
    }

    private Page<TodoMaster> searchPage(SearchRequest searchRequest){
        TodoMasterSpecification todoMasterSpecification = new TodoMasterSpecification();
        whereGeneration(searchRequest, todoMasterSpecification);

        Pageable pageable = PageRequest.of( searchRequest.getPageNumber(), searchRequest.getPageSize(), Sort.by("addDt").descending() );
        Page<TodoMaster> pageTodoMaster = masterRepository.findAll(todoMasterSpecification, pageable);
        pageTodoMaster.getContent().forEach(this::hibernateInit);

        return pageTodoMaster;
    }

}
