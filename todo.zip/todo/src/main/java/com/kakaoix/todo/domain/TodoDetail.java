package com.kakaoix.todo.domain;

import com.kakaoix.todo.domain.mixedId.TodoDetailId;
import com.kakaoix.todo.domain.TodoMaster;
import lombok.Data;

import javax.persistence.*;

import java.time.LocalDate;

@Entity
@Table(name = "todoDetail")
@Data
public class TodoDetail {
    @EmbeddedId
    private TodoDetailId todoDetailId;
}
