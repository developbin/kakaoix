package com.kakaoix.todo.error;

public class TodoException extends RuntimeException{
    public TodoException(){
        super();
    }
    public TodoException(String message){
        super(message);
    }
    public TodoException(Throwable ex){
        super(ex);
    }
    public TodoException(String message, Throwable ex){
        super(message,ex);
    }
}
