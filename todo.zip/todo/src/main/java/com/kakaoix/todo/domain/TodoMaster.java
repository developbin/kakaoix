package com.kakaoix.todo.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.ToString;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "todoMaster")
@Data
public class TodoMaster {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long todoId;
    private String name;
    private boolean status;
    private LocalDateTime addDt;
    private LocalDateTime modifyDt;

    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
    @JoinColumn(name="todoId", insertable=false, updatable=false)
    List<TodoDetail> todoDetails;

    public TodoMaster(){
        this.addDt = LocalDateTime.now();
    }
}
