package com.kakaoix.todo.repository;

import com.kakaoix.todo.domain.TodoMaster;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface TodoMasterRepository extends JpaRepository<TodoMaster, Long>, JpaSpecificationExecutor<TodoMaster> {
    Page<TodoMaster> findAll(Specification<TodoMaster> spec, Pageable pageable);
}
