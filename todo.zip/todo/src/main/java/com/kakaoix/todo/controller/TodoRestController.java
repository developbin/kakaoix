package com.kakaoix.todo.controller;

import com.kakaoix.todo.domain.TodoMaster;
import com.kakaoix.todo.request.SearchRequest;
import com.kakaoix.todo.service.TodoService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.InputStreamResource;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.ByteArrayInputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.time.LocalDate;
import java.util.*;

@Slf4j
@RestController
@RequestMapping("/api/todo")
public class TodoRestController {

    @Resource
    private TodoService todoService;

    @CrossOrigin(origins = {"http://localhost:8089" }, exposedHeaders = "fileName")
    @GetMapping("/download")
    public ResponseEntity<InputStreamResource> download(SearchRequest searchRequest) throws UnsupportedEncodingException {
        ByteArrayInputStream in = todoService.download(searchRequest);
        String fileName = URLEncoder.encode(LocalDate.now().toString()+"_"+"todoList.xlsx","UTF-8");
        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition","attachment; filename="+fileName);
        headers.add("Content-Type","application/vnd.ms-excel");
        headers.add("Content-Transfer-Encoding", "binary");
        headers.add( "filename", fileName);

        return ResponseEntity
                .ok()
                .headers(headers)
                .body(new InputStreamResource(in));
    }

    @CrossOrigin(origins = {"http://localhost:8089" })
    @PostMapping("/upload")
    public ResponseEntity<List<String>> upload(@RequestParam List<MultipartFile> files) {
        return new ResponseEntity<>(todoService.upload(files), HttpStatus.OK);
    }

    @CrossOrigin(origins = {"http://localhost:8089" })
    @GetMapping("/list")
    public ResponseEntity<Page<TodoMaster>> list(SearchRequest searchRequest){
        return new ResponseEntity<>(todoService.getPage(searchRequest), HttpStatus.OK);
    }

    @CrossOrigin(origins = {"http://localhost:8089" })
    @GetMapping("/list/ids")
    public ResponseEntity<List<TodoMaster>> listIds(@RequestParam(value="ids") List<Long> ids){
        return new ResponseEntity<>(todoService.findAllById(ids), HttpStatus.OK);
    }

    @CrossOrigin(origins = {"http://localhost:8089" })
    @GetMapping("/detail/{id}")
    public ResponseEntity<TodoMaster> detail(@PathVariable("id") long id){
        return new ResponseEntity<>(todoService.findById(id), HttpStatus.OK);
    }

    @CrossOrigin(origins = {"http://localhost:8089" })
    @PostMapping("/save")
    public ResponseEntity<TodoMaster> save(@RequestBody TodoMaster master){
        return new ResponseEntity<>(todoService.save(master), HttpStatus.OK);
    }

    @CrossOrigin(origins = {"http://localhost:8089" })
    @PutMapping("/modify")
    public ResponseEntity<TodoMaster> modify(@RequestBody TodoMaster master){
        return new ResponseEntity<>(todoService.modify(master), HttpStatus.OK);
    }

    @CrossOrigin(origins = {"http://localhost:8089" })
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> delete(@PathVariable("id") long id){
        todoService.delete(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
