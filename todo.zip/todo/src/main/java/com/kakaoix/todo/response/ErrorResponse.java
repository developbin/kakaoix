package com.kakaoix.todo.response;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ErrorResponse {
    String type;
    int code;
    String msg;
    public ErrorResponse(String type, int code, String msg){
        this.type = type;
        this.code = code;
        this.msg = msg;
    }
}
