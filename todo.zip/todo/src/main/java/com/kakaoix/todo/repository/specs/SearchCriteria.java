package com.kakaoix.todo.repository.specs;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SearchCriteria {
    private String key;
    private Object value;
    private Object tobeValue;
    private com.kakaoix.todo.repository.specs.SearchOperation operation;

    public SearchCriteria(String key, Object value, SearchOperation operation){
        this.key = key;
        this.value = value;
        this.operation = operation;
    }
    public SearchCriteria(String key, Object value, Object tobeValue, SearchOperation operation){
        this.key = key;
        this.value = value;
        this.tobeValue = tobeValue;
        this.operation = operation;
    }
    public SearchCriteria() {
    }
}
