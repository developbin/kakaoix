package com.kakaoix.todo.resolver;

import com.kakaoix.todo.domain.TodoMaster;
import com.kakaoix.todo.domain.mixedId.TodoDetailId;
import com.kakaoix.todo.error.TodoException;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.regex.Matcher;

@Component
public class FileArgumentResolver {

    @Value(value = "${upload.dir.path}")
    String uploadPath;

    public List<String> upload(List<MultipartFile> files){
        List<String> savePaths = new ArrayList<>();
        for (MultipartFile multipartFile : files) {
            if( multipartFile.isEmpty() ) throw new TodoException("파일이 존재하지 않습니다.");

            String rootPath = uploadPath.replaceAll("/", Matcher.quoteReplacement(File.separator));
            Calendar cal = Calendar.getInstance();
            Path ymd = Paths.get(String.valueOf(cal.get(Calendar.YEAR)),String.valueOf(cal.get(Calendar.MONTH)),String.valueOf(cal.get(Calendar.DATE)));
            Path ymdPath = Paths.get(rootPath.toString(), ymd.toString());

            File folder = new File(ymdPath.toString());
            if( !folder.exists() ){
                 folder.mkdirs();
            }

            String fileName = UUID.randomUUID()+"_"+multipartFile.getOriginalFilename();
            File file = new File(folder.getAbsolutePath()+File.separator+fileName);

            try{
                multipartFile.transferTo(file);
                savePaths.add(file.getAbsoluteFile().toString());
            }catch(IOException ioe){
                throw new TodoException(ioe);
            }
        }

        return savePaths;
    }

    public ByteArrayInputStream excelDownload(List<TodoMaster> masters) {
        TodoMaster todoMaster = masters.get(0);

        Class clazz = todoMaster.getClass();
        Field[] fields = clazz.getDeclaredFields();
        List<String> columns = new ArrayList<>();
        for (Field field : fields) {
            columns.add(field.getName());
        }

        try (
                Workbook workbook = new XSSFWorkbook();
                ByteArrayOutputStream out = new ByteArrayOutputStream()
        ) {
            CreationHelper createHelper = workbook.getCreationHelper();
            Sheet sheet = workbook.createSheet("TodoList");

            Font headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerFont.setColor(IndexedColors.BLUE.getIndex());

            CellStyle cellStyle = workbook.createCellStyle();
            cellStyle.setFont(headerFont);

            Row headerRow = sheet.createRow(0);
            for (int col = 0; col < columns.size(); col++) {
                Cell cell = headerRow.createCell(col);
                cell.setCellStyle(cellStyle);
                cell.setCellValue(columns.get(col));
            }

            CellStyle longCellStyle = workbook.createCellStyle();
            longCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("#"));
            CellStyle dateCellStyle = workbook.createCellStyle();
            dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("yyyy-mm-dd"));

            int idx = 1;
            for (TodoMaster master : masters) {
                Row row = sheet.createRow(idx++);
                Cell todoIdCell = row.createCell(0);
                todoIdCell.setCellValue(master.getTodoId());
                todoIdCell.setCellStyle(longCellStyle);

                row.createCell(1).setCellValue(master.getName());
                row.createCell(2).setCellValue(master.isStatus());
                row.createCell(3).setCellValue(master.getAddDt().toString());

                StringJoiner joiner = new StringJoiner(",");
                master.getTodoDetails().forEach(item->{
                    TodoDetailId detailId = item.getTodoDetailId();
                    joiner.add(String.valueOf(detailId.getReferTodoId()));
                });
                row.createCell(5).setCellValue(joiner.toString());
            }

            workbook.write(out);
            return new ByteArrayInputStream(out.toByteArray());
        } catch (IOException e) {
            throw new TodoException(e);
        }
    }
}
