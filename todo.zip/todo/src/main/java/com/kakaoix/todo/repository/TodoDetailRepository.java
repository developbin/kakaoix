package com.kakaoix.todo.repository;

import com.kakaoix.todo.domain.TodoDetail;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface TodoDetailRepository extends JpaRepository<TodoDetail, Long> {
//    @Modifying
//    @Query(value="update TodoDetail td set td.name = :#{#detail.name}, td.status = :#{#detail.status}, td.modifyDt = :#{#detail.modifyDt} "+
//                 "where td.todoDetailId.todoId = :#{#detail.todoDetailId.todoId}", nativeQuery=false)
//    Integer detailUpdate(@Param("detail") TodoDetail detail);
}
