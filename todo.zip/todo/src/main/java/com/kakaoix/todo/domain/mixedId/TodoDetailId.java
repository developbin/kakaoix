package com.kakaoix.todo.domain.mixedId;

import lombok.Data;

import javax.persistence.Embeddable;
import java.io.Serializable;

@Data
@Embeddable
public class TodoDetailId implements Serializable {
    private long todoId;
    private long referTodoId;
}
