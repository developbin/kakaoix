import Vue from 'vue'
import Router from 'vue-router'
import TodoApp from "@/components/TodoApp";
import TodoUpload from "@/components/TodoUpload";


Vue.use(Router)

export default new Router({
  mode: 'history',
  routes: [
    { path: '/', name: 'TodoApp', component: TodoApp },
    { path: '/upload', name: 'TodoUpload', component: TodoUpload }
  ]
})
