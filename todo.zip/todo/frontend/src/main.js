// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import axios from 'axios'
import BootstrapVue from 'bootstrap-vue'
import Header from '@/components/common/Header.vue'
import Footer from '@/components/common/Footer.vue'
import moment from 'moment';
import VModal from 'vue-js-modal';
import 'bootstrap/dist/css/bootstrap.css'
import 'bootstrap-vue/dist/bootstrap-vue.css'

Vue.config.productionTip = false;

Vue.prototype.$axios = axios;
Vue.prototype.$moment = moment;
Vue.prototype.$API_DEFAULT_URL = 'http://localhost:8080/api';
window.moment = moment;

Vue.use(BootstrapVue);
Vue.use(VModal, { dynamic: true });
Vue.use(moment);
Vue.component('Header', Header);
Vue.component('Footer', Footer);

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  components: { App },
  template: '<App/>'
});
