<template>
  <modal name="dynamic-modal" width="400" height="500" @before-open="beforeOpen" @before-close="beforeClose">

    <div>
        <label>todo 번호</label>
        <b-form-input type="text" :value="item.todoId" disabled></b-form-input>
        <label>참조 todo 번호 ></label>
        <template v-for="detail in item.todoDetails" v-cloak>
          @{{detail.todoDetailId.referTodoId}}
        </template>
        <br/>
        <label>todo명</label>
        <b-form-input type="text" v-model="item.name" :value="item.name"></b-form-input>
        <br/>
        <b-form-group label="완료상태">
          <b-form-radio v-model="item.status" name="some-radios" value="true">완료</b-form-radio>
          <b-form-radio v-model="item.status" name="some-radios" value="false">미완료</b-form-radio>
        </b-form-group>
        <b-button squared variant="primary" @click="modify">수정</b-button>
        <b-button squared variant="primary" @click="close">닫기</b-button>
    </div>
  </modal>
</template>
<script>
  export default {
    data () {
      return {
        selected : null,
        todoId : '',
        item : {},
        referTodoDetailItem : []
      }
    },
    methods: {
      async beforeOpen (e) {
        //파라미터
        this.todoId = e.params.todoId;
        await this.axiosListDetail();

        let todoDetails = this.item.todoDetails;
        let referTodoIds = [];
        if( todoDetails.length > 0 ){
            todoDetails.forEach((item,idx)=>{
              referTodoIds.push(item.todoDetailId.referTodoId);
          });
        }

        if( referTodoIds.length > 0 ){
          let params = this.addParams(referTodoIds);
          await this.axiosListInIds(params);
        }
      },
      async axiosListDetail(){
        let $this = this;
        await $this.$axios.get($this.$API_DEFAULT_URL + '/todo/detail/'+$this.todoId,{timeout: 2500})
          .then((result) => {
              $this.item = result.data;
          }).catch((ex)=>{
              console.warn("error >",ex);
          });
      },
      async axiosListInIds(params){
        let $this = this;
        await $this.$axios.get($this.$API_DEFAULT_URL + '/todo/list/ids'+params,{timeout: 2500})
          .then((result) => {
              $this.referTodoDetailItem = result.data;
          }).catch((ex)=>{
              console.warn("error >",ex);
          });
      },
      modify(){
        if( this.valid() ){
          let $this = this;
          let content = {};
          content.name = this.item.name;
          content.todoId = this.item.todoId;
          content.status = this.item.status;
          $this.$axios.put($this.$API_DEFAULT_URL + '/todo/modify', content)
            .then((result) => {
              $this.beforeClose();
              $this.close();
            }).catch((ex)=>{
              console.warn("error >",ex);
          });
        }
      },
      valid(){
        if( this.item.name.length < 1 ){
          alert('todo 명을 입력하여 주시기 바랍니다.');
          return false;
        }
        if( this.referTodoDetailItem.length > 0 ) {
          for (let item of this.referTodoDetailItem) {
            if( !item.status) {
              alert('참조Todo아이디 '+item.todoId+'이 미완료 상태입니다.');
              return false;
            }
          }
        }
        return true;
      },
      addParams(arr){
        if(!arr) return '';
        let params = '';
        for (let i=0; i<arr.length; i++){
          if( i == 0 ){
            params='?'
          }
          params+='ids='+arr[i];
          params+= i < arr.length-1 ? '&' : '';
        }
        return params;
      },
      beforeClose () {
        this.dataInitial();
        this.$emit('refresh', undefined);
      },
      close () {
        this.$modal.hide('dynamic-modal');
      },
      dataInitial(){
        this.selected = null;
        this.todoId = '';
        this.item = {};
        this.referTodoDetailItem = [];
      },
      fnDialog (titl, txt) {
        this.$modal.show('dialog', {
          title: titl,
          text: txt,
          buttons: [
            {
              title: 'Close'
            }
          ]
        })
      }
    }
  }
</script>
