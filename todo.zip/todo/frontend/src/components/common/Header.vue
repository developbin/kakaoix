<template>
<nav class="navbar navbar-expand-md fixed-top navbar-dark bg-dark">
      <router-link class="navbar-brand" to="/"  >TODO-PROJECT</router-link>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsExampleDefault">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active" @click="menuActive">
            <router-link class="nav-link" to="/"  >TODO 관리<span class="sr-only"></span></router-link>
          </li>
          <li class="nav-item" @click="menuActive">
            <router-link class="nav-link" to="/upload"  >TODO 업로드<span class="sr-only"></span></router-link>
          </li>
        </ul>
      </div>
    </nav>
</template>

<script>
export default {
  name: 'Header',
  data(){
    return{
      menuList : [
        {}
      ]
    }
  },
  methods:{
    init : function(){
    },
    menuActive : function(e){
      let target = $(e.target).parent();
      target.siblings().removeClass('active');
      target.addClass('active');
    }
  },
  mounted(){
    this.init();
  }
}
</script>
