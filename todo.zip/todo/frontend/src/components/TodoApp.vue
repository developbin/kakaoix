<template>
  <div class="table-responsive-sm" style="padding-top: 75px;">
<!--    <h5 >TODO 관리 <b-badge v-if="items != null && items.length > 0">{{items.length}}</b-badge></h5>-->
    <b-form inline onSubmit="return false;" style="margin-bottom: 10px;">
      <label>추가일자 : </label> &nbsp
      <label for="datepicker-start">시작일</label>&nbsp
      <b-form-datepicker id="datepicker-start" reset-button :state="startDtStat" v-model="strFormatStartDt" @input="onStartDtChanged($event)"></b-form-datepicker>&nbsp
      <label for="datepicker-end">종료일</label>&nbsp
      <b-form-datepicker id="datepicker-end" reset-button :state="endDtStat" v-model="strFormatEndDt" @input="onEndDtChanged($event)"></b-form-datepicker>&nbsp
      <label>완료상태</label> &nbsp
      <b-form-select
        v-model="select.selected"
        :options="select.options"
        text-field="name"
        disabled-field="notEnabled"
      ></b-form-select>
    </b-form>
    <b-form inline onSubmit="return false;" style="margin-bottom: 10px;">
    <b-input id="inline-form-input-name" class="mb-2 mr-sm-2 mb-sm-0" @keyup.enter="getList" v-model="query.name"></b-input>
    <b-button variant="primary" @click="search">검색</b-button>&nbsp
    <b-button variant="primary" @click="save">생성</b-button>&nbsp
    <b-button variant="primary" @click="download">엑셀 다운로드</b-button>
    </b-form>
    <table class="b-table table table-bordered table-striped bv-docs-table">
      <thead class="thead-default">
      <tr>
        <th></th>
        <th>TODO 번호</th>
        <th>TODO 참조번호</th>
        <th>TODO 명</th>
        <th>완료상태</th>
        <th>추가일자</th>
        <th>수정</th>
        <th>삭제</th>
      </tr>
      </thead>
      <tbody>
      <template v-if="items.length > 0" v-cloak>
        <tr v-for="item in items" v-cloak>
          <td><b-form-checkbox :value="item.todoId" v-model="checkedIds" class="mb-2 mr-sm-2 mb-sm-0" onsubmit="return false"></b-form-checkbox></td>
          <td>{{item.todoId}}</td>
          <td>
            <template v-for="detail in item.todoDetails">
              @{{detail.todoDetailId.referTodoId}}
            </template>
          </td>
          <td>{{item.name}}</td>
          <td>{{item.status ? '완료' : '미완료'}}</td>
          <td>{{item.addDt | formatDate('YYYY.MM.DD')}}</td>
          <td><b-button squared variant="primary" :value="item.todoId" @click="openPopup">Edit</b-button></td>
          <td><b-button squared variant="outline-danger" @click="del" :value="item.todoId" >X</b-button></td>
        </tr>
      </template>
      <template v-else v-cloak>
        <td colspan="8">데이터가 존재하지 않습니다.</td>
      </template>

      </tbody></table>
        <b-row>
          <b-col md="6" class="my-1">
            <b-pagination
              @change="onPageChanged"
              :value="1"
              :total-rows="query.totalRow"
              :per-page="query.pageSize"
              :v-model="this.query.pageNumber"
              class="my-0"
            />
          </b-col>
        </b-row>
      <DynamicModal @refresh="refresh"></DynamicModal>
  </div>
</template>

<script>
  // @ is an alias to /src
  import Vue from 'vue'
  import DynamicModal from "@/components/common/DynamicModal.vue";
  Vue.component('DynamicModal',DynamicModal);

  export default {
    data : function(){
      return {
        items : [],
        checkedIds: [],
        startDtStat : true,
        endDtStat : true,
        strFormatStartDt : null,
        strFormatEndDt : null,
        select : {
          selected:null
          ,options:[
            { value: null, name: '전체' },
            { value: true, name: '완료' },
            { value: false, name: '미완료' }
          ]
        },
        query : {
          pageNumber : 0,
          pageSize : 10,
          totalRow : 0,
          totalPage : 0,
          startDt : null,
          endDt : null,
          name : '',
          stat : null
        }
      }
    },
    filters: {
      formatDate: function(value, format) {
        let $this = this;
        const DEFAULT_FORMAT = 'YYYY.MM.DD hh:mm:ss';
        if (typeof value === 'string') {
          return moment(value).format(format?format:DEFAULT_FORMAT);
        }
      }
    },
    methods : {
      onStartDtChanged(e){
        if( (e && this.strFormatEndDt) || (!e && !this.strFormatEndDt) ){
          this.startDtStat = true;
          this.endDtStat = true;
        }else{
          this.startDtStat = false;
        }
      },
      onEndDtChanged(e){
        if( (e && this.strFormatStartDt) || (!e && !this.strFormatStartDt) ){
          this.startDtStat = true;
          this.endDtStat = true;
        }else{
          this.endDtStat = false;
        }
      },
      search(){
        if( this.strFormatStartDt && this.strFormatEndDt ){
          this.query.startDt = this.strFormatStartDt+'T00:00:00';
          this.query.endDt = this.strFormatEndDt+'T00:00:00';
        }else{
          this.query.startDt = null;
          this.query.endDt = null;
        }
        this.query.stat = this.select.selected;
        this.getList();
      },
      onPageChanged(pageNum){
        this.query.pageNumber = pageNum-1;
        this.getList();
      },
      initData(){
        this.items = [];
        this.checkedIds = [];
        this.startDtStat = true;
        this.endDtStat = true;
        this.strFormatStartDt = null;
        this.strFormatEndDt = null;
        this.query.pageNumber = 0;
        this.query.pageSize = 10;
        this.query.totalRow = 0;
        this.query.totalPage = 0;
        this.query.startDt = null;
        this.query.endDt = null;
        this.query.name = '';
        this.query.stat = null;
        this.select.selected = null;
      },
      openPopup(e){
        this.$modal.show('dynamic-modal',{
          todoId : e.currentTarget.value,
        });
      },
      save(){
        if( !this.query.name ) {
          alert('todo명이 존재하지 않습니다.');
          return false;
        }

        let $this = this;
        let content = {};
        content.name = this.query.name;
        if( this.checkedIds && this.checkedIds.length > 0 ){
          content.todoDetails = [];
          this.checkedIds.forEach((item, idx)=>{
            content.todoDetails.push({});
            content.todoDetails[idx].todoDetailId = {};
            content.todoDetails[idx].todoDetailId.referTodoId = item;
          });
        }

        $this.$axios.post($this.$API_DEFAULT_URL + '/todo/save', content)
             .then((result) => {
               $this.initData();
               $this.getList();
             }).catch((ex)=> {
                console.warn("error >",ex);
             });
      },
      del(e){
        let todoId = e.currentTarget.value;
        let $this = this;
        $this.$axios.delete($this.$API_DEFAULT_URL + '/todo/delete/'+todoId)
              .then((result) => {
                $this.initData();
                $this.getList();
              }).catch((ex)=>{
                console.warn("error >",ex);
              });
      },
      getList(){
        let $this = this;
        $this.$axios.get($this.$API_DEFAULT_URL + '/todo/list',{params: $this.query})
             .then((result) => {
               let data = result.data;
               this.query.totalRow = data.totalElements;
               this.query.totalPage = data.totalPages;
               $this.items = data.content;
            }).catch((ex)=>{
                console.warn("error >",ex);
            });
      },
      download(){
        if(!this.items || this.items.length < 1){
          alert('데이터가 존재하지 않습니다.');
          return false;
        }

        let $this = this;

        $this.$axios.get($this.$API_DEFAULT_URL + '/todo/download',{params: $this.query, responseType: 'blob'})
                 .then((response) => {
                    const url = window.URL.createObjectURL(new Blob([response.data], { type: response.headers['content-type'] }));
                    const link = document.createElement('a');
                    link.href = url;
                    link.setAttribute('download', response.headers['filename']);
                    document.body.appendChild(link);
                    link.click();
                }).catch((ex)=>{
                    console.warn("error >",ex);
                });
      },
      refresh(){
        this.initData();
        this.getList();
      }
    },
    mounted : function(){
      this.getList();
    }
  }
</script>
