<template>
  <div class="table-responsive-sm" style="padding-top: 75px;">
    <form method="post" id="uploadForm" enctype="multipart/form-data" onsubmit="return false">
      <input type="file" name="files" multiple />
      <input type="button" value="전송" @click="upload">
    </form>
    <template v-if="uploadPathNames && uploadPathNames.length > 0">
      업로드 Paths : <br>
      <template v-for="pathName in uploadPathNames" v-cloak>
        <label>{{pathName}}</label><br>
      </template>
    </template>
  </div>
</template>

<script>
  // @ is an alias to /src
  export default {
    data : function(){
      return {
        uploadPathNames : []
      }
    },
    methods : {
      upload(e){
        let $this = this;
        let formData = new FormData(document.getElementById('uploadForm'));
        $this.$axios.post($this.$API_DEFAULT_URL + '/todo/upload', formData,{
            headers : {
              'content-Type' : 'multipart/form-data'
            }
          }).then((result) => {
            if(result.data){
              alert('업로드 완료');
              this.uploadPathNames = result.data;
            }
          }).catch((ex)=> {
            console.warn("error >",ex);
        });
      }
    }
  }
</script>
