<template>
  <div id="app">
    <Header></Header>
    <router-view/>
    <modals-container/>
    <Footer></Footer>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>
